<?php
Class login_module extends CI_Model
{
 	function loginsub($username, $password)
 	{
		
   		$this -> db -> select('*');
   		$this -> db -> from('user_master');
   		$this -> db -> where('username', ''.$username.'');
   		$this -> db -> where('password',''.$password.'');
		$this->db->where('user_type_id','1');
   		$this -> db -> limit(1);
   		$query = $this -> db -> get();
		
   		if($query -> num_rows() == 1)
   		{
     		return $query->result();
   		}
   		else
   		{	
     		return false;
   		}
 	}
 
 	function get_current_year(){
		$this -> db -> select('*');
   		$this -> db -> from('account_year_mst');
   		$this -> db -> where('status = ', 'Active');
    	$query = $this -> db -> get();
    	$the_content = $query->result_array();
    	return $the_content;
	}
 	
  	
  
	
}
?>
