<!DOCTYPE html>
<html lang="en">
<head>
	<title>pokemon</title>
	<link rel="stylesheet" href="<?=base_url();?>asset/css/font-icons/entypo/css/entypo.css">
	<link rel="stylesheet" href="<?=base_url();?>asset/css/neon-forms.css">
	<script src="<?=base_url();?>asset/js/jquery-1.11.0.min.js"></script>
    <link rel="stylesheet" href="<?=base_url();?>asset/css/styles.css">
    <script src="<?=base_url();?>asset/js/select2/select2.min.js"></script>
    <script src="<?=base_url();?>asset/js/bootbox/jquery.bootbox.js"></script>
    <script src="<?=base_url();?>asset/js/jquery.dataTables.min.js"></script>
	<script src="<?=base_url();?>asset/js/all_fun.js"></script>
	<script src="<?=base_url();?>asset/js/bootstrap.js"></script>	
	</head>
	<body class="page-body">
