<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en"><!--<![endif]--><!-- BEGIN HEAD --><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
   <meta charset="utf-8">
   <title>Login</title>
   <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <meta content="" name="description">
   <meta content="" name="author">
  
  
   
   
  
</head>
<script type="text/javascript" charset="utf-8">//
	$(document).ready(function() {
		
		<!---------This Method is use for change status-------------->
		$(document).on('click', '.login-btn', function (e) {
			if($('#username').val()==""){
				$("#username").focus();
				return false;
			}
			if($('#password').val()==""){
				$("#password").focus();
				return false;
			}
		});
		
	});		
</script>
<body class="lock">
    
    <div class="login-wrap">
        
                <span>Login</span>
            
        </div>
           <form method="post" action="<?=base_url()?>index.php/login/login_submit">
        <div class="metro double-size green">
           
                <div class="input-append lock-input">
                    <input class="" name="username" id="username" value="" placeholder="Username" type="text">
                </div>
            
        </div>
        <div class="metro double-size yellow">
          
                <div class="input-append lock-input">
                    <input class="" name="password" id="password" value="" placeholder="Password" type="password">
                </div>
           
        </div>
        <div class="metro single-size terques login">
         
                <button type="submit" class="btn login-btn">
                    Login
                    <i class=" icon-long-arrow-right"></i>
                </button>
           
        </div>
        </form>
       
    </div>

</body><!-- END BODY --></html>
<style>
.lock{
  margin: 20% 20% 20% 45%;
}
#username{
  width: 200px;
height: 30px;
margin-top:20px;
  }
  #password{
     width: 200px;
height: 30px;
margin-top:20px;

  }
  
.login-btn {
    margin-top: 20px;
    width: 70px;
    height: 30px;
  }
  </style>

