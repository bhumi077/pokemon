// JavaScript Document

$(document).ready(function() {
	var url_list=$("#url_list").val();
	var oTable = $('#example').dataTable( {
		"bProcessing": true,
		sPaginationType: "full_numbers",
		"sAjaxSource":url_list,
		"iDisplayLength": 25,
		"bDestroy": true
	});
	$(".dataTables_wrapper select").select2({
			minimumResultsForSearch: -1
	 });
	
	//delete function//
	$(document).on('click', '.delrcd', function (e) {
				e.preventDefault();
				var url = $(this).attr('value');
				var aPos = oTable.fnGetPosition( $(this).closest('tr').get(0) );
				bootbox.confirm("Do you really want to delete ?", "Cancel", "Yes, remove", function (r) {
            		if (r){
   						oTable.fnDeleteRow(aPos);
                    	$.ajax({url:url,success:function(result){
						 	var a=1;	
						 	$('#example tbody tr').each(function(){$(this).find("td:first").text(a);a++;});
                    	}});
            		}
					
        		});
		});
		
	//status change
	$(document).on('click', '.statuschange', function (e) {
			e.preventDefault();
			var url = $(this).attr('value');
			$.ajax({url:url,success:function(result){
					var oTable = $('#example').dataTable( { 
						"bProcessing": true,sPaginationType: "full_numbers","sAjaxSource":url_list,"iDisplayLength": 25,"bDestroy": true
			  		});
					$(".dataTables_wrapper select").select2({minimumResultsForSearch: -1});	 	
            }});	
		});	

});
