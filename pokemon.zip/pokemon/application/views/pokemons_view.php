 
<link href="<?=base_url();?>asset/css/style.css" rel="stylesheet">
		<section id="content">
			<div class="container">
				<div class="row">

					<!-- ==== SIDEBAR START == -->

					
					<div class="col-sm-12">
                        <ul class="gallery">
                         <?php for($i=0;$i<count($pokemon);$i++){ 
						  	?>
                            <li>
                            	
                            	<div class="col-sm-2 pokemon">
                            	<img src="<?=base_url();?>admin/upload/event_thum/<?=$pokemon[$i]['img_path']?>" />
                                </div>
                                <div class="col-sm-2 pok">
                                   <h2>Name: <?=$pokemon[$i]['pokemon_name']?></h2>
                                   <h2>Type: <?=$pokemon[$i]['Type']?></h2>
                                   <h2>Species: <?=$pokemon[$i]['Species']?></h2>
                                   <h2>Weight: <?=$pokemon[$i]['Weight']?></h2>
                                   
                               </div>

                            </li>
                          <?php }?>
                        </ul>
					</div>

				</div>
			</div>
		</section>

<style>
body {
    overflow-x: hidden;
    padding-top: 0px;
}
section {
    padding: 30px 0;
}
.container{
	margin-top:20px;
}
.pokemon img{
	width: 100px;
	height: 150px;
}
h2{
	font-size:14px;
  font-weight: 600;
}
.pokemon {
    margin-top: 0px;
}
</style>