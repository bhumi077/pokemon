<?php
Class pokemons_model extends CI_Model
{
 	
	
	
	function get_pokemon(){
		$this -> db -> select('*');
   		$this -> db -> from('pokemon_master');
		$this -> db -> where('status','Active');
		$query = $this -> db -> get();
    	$the_content = $query->result_array();
    	return $the_content;
	}	
}
?>
