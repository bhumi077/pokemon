<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class pokemons extends CI_Controller {

	function __construct()
 	{
   		parent::__construct(); 
		$this->load->model('pokemons_model','',TRUE);
   		$this->load->helper('form');
   		$this->load->helper('url');
		$this->load->helper('date');
	
		
 	}
	public function index()
	{
		
		// /$data['result']=$this->pokemons_model->get_contain();
		$data['pokemon']=$this->pokemons_model->get_pokemon();
		$this->load->view('pokemons_view',$data);
		
	}
	
	
}


